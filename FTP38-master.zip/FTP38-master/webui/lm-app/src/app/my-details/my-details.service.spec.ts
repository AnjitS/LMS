import { TestBed, inject } from '@angular/core/testing';

import { MyDetailsService } from './my-details.service';

describe('MyDetailsService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [MyDetailsService]
    });
  });

  it('should be created', inject([MyDetailsService], (service: MyDetailsService) => {
    expect(service).toBeTruthy();
  }));
});
