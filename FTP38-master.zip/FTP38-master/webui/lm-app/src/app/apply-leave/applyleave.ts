export class ApplyLeave {
    empId:number=null;
    levId:number;
    levStartDate:Date=null;
    levEndDate:Date=null;
    levType:String=null;
    levStatus:String=null;
    levReason:String=null;
    levAppliedOn:Date=null;
    levNoOfDays:number=null;
    levMgrComments:String;
    constructor(){ }
    

}
