export class LeaveDetails {
    empId: number;
    levId: number;
    levStartDate: string;
    levEndDate: string;
    levType: string;
    levStatus: string;
    levReason: string;
    levAppliedOn: string;
    levMgrComments: string;
    levNoOfDays: number;
    //   constructor(empId: number, levId: number, levStartDate: string,  levEndDate: string , levType: string, levStatus: string ,levReason: string, 
    //     levAppliedOn: string, levMgrComments: string, levNoOfDays: number) {
    //       this.empId = empId;
    //       this.levId = levId;
    //       this.levStartDate = levStartDate;
    //       this.levEndDate = levEndDate;
    //       this.levType = levType;
    //       this.levStatus = levStatus;
    //       this.levReason = levReason;
    //       this.levAppliedOn = levAppliedOn;
    //       this.levMgrComments = levMgrComments;
    //       this.levNoOfDays = levNoOfDays;
    // }
    constructor(){}
}
