# Rest Service

 This top level directory contains all the relevant code for the rest service. The sub-directory 'leavemanager' contains a maven project for the application
 and the sub-directory 'integration_tests' contains the integration tests for the rest service (which is also another maven project)

# manual testing for the rest api
  * ```curl http://localhost:8080/ftp38/api/employees```
