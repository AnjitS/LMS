package com.hexaware.ftp38.model;
  /**
 * LeaveType class to store employee leave type.
 * @author hexware
 */
public enum LeaveType {
  /**
   * EARNED LEAVE  leave type.
   */
        EARNEDLEAVE
}
